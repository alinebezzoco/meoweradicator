## Meoweradicator 
Extensão para o Google Chrome que permite substituir a caixa de comentários do feed de notícias do seu Facebook para fotos lindas e fofas de gatinhos.

### Version 1.0
Download: https://chrome.google.com/webstore/detail/meoweradicator/pgfkleipcoigoaodklecabbaihjajedc

### About
O Meoweradicator é uma extensão do Google Chrome gratuita indicado para as pessoas que estão cansadas de ler os comentários do feed de notícias dos amigos e também nas páginas nas quais seguem.

Em vez de ficar triste lendo esses tipos de comentários que tal ficar olhando para fotos lindas e aleatórias de gatinhos?
